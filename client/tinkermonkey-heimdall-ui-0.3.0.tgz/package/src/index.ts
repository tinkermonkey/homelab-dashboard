// Heimdall Design System
// Public API barrel export

import './tokens/tokens.css'

export { Icon, type IconName } from './components/Icon'
export { Button } from './components/Button'
export { Chip } from './components/Chip'
export { Badge, StatusBadge } from './components/Badge'
export { TextInput } from './components/TextInput'
export { TextArea } from './components/TextArea'
export { NumberInput } from './components/NumberInput'
export { Select } from './components/Select'
export { TriState } from './components/TriState'
export { Field } from './components/Field'
export { StatTile, type StatTileProps } from './components/StatTile'
export { VersionPill, type VersionPillProps } from './components/VersionPill'
export {
  SegmentedControl,
  type SegmentedControlProps,
  type SegmentedControlOption,
} from './components/SegmentedControl'
export { Table, type Column } from './components/Table'
export { NavItem } from './components/NavItem'
export { Sidebar } from './components/Sidebar'
export { Topbar, type TopbarProps } from './components/Topbar'
export { TabBar } from './components/TabBar'
export { AppTitle, type AppTitleProps } from './components/AppTitle'
export { Titlebar, type TitlebarProps } from './components/Titlebar'
export {
  Statusbar,
  type StatusbarProps,
  type StatusbarTone,
  type StatusbarPulseItem,
  type StatusbarIconItem,
  type StatusbarDividerItem,
  type StatusbarItem,
} from './components/Statusbar'
export { ShellLayout, type ShellLayoutProps } from './components/ShellLayout'
export { Modal, type ModalProps } from './components/Modal'
export { ConfirmDialog } from './components/ConfirmDialog'
export { WorkspaceSwitcherDialog, type WorkspaceSwitcherDialogProps, type Workspace } from './components/WorkspaceSwitcherDialog'
export {
  FilterDropdown,
  type FilterDropdownProps,
  type FilterDropdownTriggerProps,
  type FilterDropdownPanelProps,
  type FilterDropdownSectionProps,
  type FilterDropdownCheckboxProps,
  type FilterDropdownRadioProps,
} from './components/FilterDropdown'
export { Toast, type ToastProps, type ToastVariant } from './components/Toast'
export { CommandPalette, type Command } from './components/CommandPalette'
export { Panel } from './components/Panel'
export { Drawer } from './components/Drawer'
export { SplitPane } from './components/SplitPane'
export { StatGrid } from './components/StatGrid'
export {
  InspectorPanel,
  type InspectorPanelProps,
  type InspectorPanelSectionProps,
  type InspectorPanelPropertySectionProps,
  type PropertyRow,
} from './components/InspectorPanel'
export { KVGrid, type KVGridProps, type KVGridRow } from './components/KVGrid'
export { Sparkline, type SparklineColor, type SparklineProps } from './components/Sparkline'
export { LineChart, type LineChartProps, type ThresholdLine, type EventMarker } from './components/LineChart'
export { BarChart, type BarChartSeries, type BarChartProps } from './components/BarChart'
export { BarV, type BarVProps } from './components/BarV'
export { BarH, type BarHProps, type BarHItem } from './components/BarH'
export { StackedBar, type StackedBarProps, type StackedBarStack } from './components/StackedBar'
export { Donut, type DonutProps, type DonutSlice } from './components/Donut'
export { Heatmap, type HeatmapProps } from './components/Heatmap'
export {
  StatusTimeline,
  type StatusTimelineProps,
  type StatusTrack,
  type StatusSegment,
  type SegmentKind,
} from './components/StatusTimeline'
export type { StatusColor } from './components/statusColors'
export { PieChart, type PieChartSegment, type PieChartProps } from './components/PieChart'
export { ProgressBar, type ProgressBarColor, type ProgressBarProps } from './components/ProgressBar'
export { MetricRow, type MetricRowProps } from './components/MetricRow'
export { PageHeader, type PageHeaderProps } from './components/PageHeader'
export { FilterBar, type FilterBarProps, type FilterChip } from './components/FilterBar'
export {
  ActivityTimeline,
  type ActivityTimelineProps,
  type ActivityEvent,
  type ActivityEventType,
} from './components/ActivityTimeline'
export { AlertStrip, type AlertStripProps, type Alert, type AlertSeverity } from './components/AlertStrip'
export { QuickAccessGrid, type QuickAccessGridProps, type QuickAccessGridItem } from './components/QuickAccessGrid'
export { QuickAccessTile, type QuickAccessTileProps } from './components/QuickAccessTile'
export { ConfigTile, type ConfigTileProps, type ConfigTileSummaryItem } from './components/ConfigTile'
export { ChatMessage, ToolBlock, ThinkingBlock, type ChatMessageProps, type ToolBlockProps, type ToolBlockData, type ThinkingBlockProps, type ThinkingBlockData } from './components/ChatMessage'
export { ChatDivider, type ChatDividerProps } from './components/ChatDivider'
export { ChatSuggestions, type ChatSuggestionsProps } from './components/ChatSuggestions'
export { ChatComposer, type ChatComposerProps, type ContextItem, type Attachment } from './components/ChatComposer'
export { ChatContainer, type ChatContainerProps, type BotTab } from './components/ChatContainer'
export { EntityPicker, type EntityPickerProps, type EntityPickerResult } from './components/EntityPicker'
export { KeyValueEditor, type KeyValueEditorProps, type KeyValueRow } from './components/KeyValueEditor'
export { OrderedList, type OrderedListProps, type OrderedItem } from './components/OrderedList'
export { RelationshipBuilder, type RelationshipBuilderProps, type RelationshipBuilderValue } from './components/RelationshipBuilder'
export { RowMenu, type RowMenuProps, type RowMenuAction } from './components/RowMenu'
export { PipelineCard, type PipelineCardProps, type Pipeline, type FlowNode } from './components/PipelineCard'
export { FormCallout, type FormCalloutProps } from './components/FormCallout'
export {
  GraphCanvas,
  useGraphCanvas,
  type GraphNodeData,
  type GraphEdge as GraphEdgeData,
  type GraphCanvasProps,
  type BaseGraphNodeComponentProps,
} from './components/GraphCanvas'
export { type GraphCanvasContextValue } from './components/GraphCanvasContext'
export { GraphNode, type GraphNodeProps } from './components/GraphNode'
export { GraphEdge, type GraphEdgeProps } from './components/GraphEdge'
export { forceLayout, type LayoutNode, type LayoutEdge, type ForceLayoutOptions } from './utils/graphLayout'
export {
  GraphInspector,
  type GraphNodeMetadata,
  type RelationshipLink,
  type GraphInspectorProps,
} from './components/GraphInspector'
export { TopologyNode, type TopologyNodeStatus, type TopologyNodeMetric, type TopologyNodeProps } from './components/TopologyNode'
export { bezierPath, rectEdgePoint, type Point, type BezierPathResult } from './utils/graph'
export { HierarchyRow, type HierarchyRowProps, type HierarchyKind } from './components/HierarchyRow'
export { HierarchyTree, type HierarchyTreeProps } from './components/HierarchyTree'
